import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDatepickerModule, BsDropdownModule, ModalModule, PaginationModule } from 'ngx-bootstrap';
import { AuthNavbarComponent } from './components/auth-navbar/auth-navbar.component';
import { AuthSidebarComponent } from './components/auth-sidebar/auth-sidebar.component';
import { AuthContentComponent } from './components/auth-content/auth-content.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertService } from './services/alert.service';
import { AccountService } from './services/account.service';
import { ValidatorsService } from './services/validator.service';
import { SharedsService } from './services/shareds.service';
import { MemberService } from '../authentication/serivce/member.service';


// Thai lang for date
import { defineLocale } from 'ngx-bootstrap/chronos';
import { thLocale } from 'ngx-bootstrap/locale';
defineLocale('th', thLocale);


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    ModalModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [
    AuthNavbarComponent,
    AuthSidebarComponent,
    AuthContentComponent
  ],
  exports : [
    AuthNavbarComponent,
    PaginationModule,
    BsDropdownModule,
    AuthSidebarComponent,
    AuthContentComponent,
    ReactiveFormsModule,
    BsDatepickerModule,
    FormsModule,
    ModalModule
  ],
  providers : [
    AlertService,
    // AccountService,
    ValidatorsService,
    SharedsService,
    MemberService
  ]
})
export class SharedsModule { }
