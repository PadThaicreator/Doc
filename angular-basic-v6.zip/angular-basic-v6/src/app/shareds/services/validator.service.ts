import { Injectable } from "@angular/core";
import { AbstractControl } from "@angular/forms";

@Injectable()

export class ValidatorsService {
    comparePassword(passwordField: string) {

        return function (confirmPassword: AbstractControl) {
            if (!confirmPassword.parent) return;
            const password = confirmPassword.parent.get(passwordField);

            const passwordSubscripe = password.valueChanges.subscribe(() => {
                confirmPassword.updateValueAndValidity();
                passwordSubscripe.unsubscribe();
            })

            if (confirmPassword.value === password.value) {
                return;
            }

            return { compare: true }
        }
    }

    isPassword(password : AbstractControl){
        if(password.value == '') return;
        if(/^[A-z0-9]{6,15}$/.test(password.value)) return;

        return { password : true};
    }
}