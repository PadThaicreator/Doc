import { Injectable } from "@angular/core";
import { AlertService } from "./alert.service";


@Injectable()

export class SharedsService {
  
  positionItem: any[] = [
    'Frontend Developer',
    'Backend Developer'
  ];



  onConvertImage(input : HTMLInputElement) {
   return new Promise((resolve , reject)=>{
     const imageType = ['image/jpg' , 'image/png' , 'image/jpeg' ];
    const imageSize = 200;
    if(input.files.length == 0) return resolve(null);

    if(imageType.indexOf(input.files[0].type) < 0){
     
      return reject({Message : "Please choose only image file"})
    }
      // console.log(input)

      if((input.files[0].size /1024) > imageSize){
        reject({Message : `Please choose image size smaller than ${imageSize} KB`})
      }
      const reader = new FileReader();

      reader.readAsDataURL(input.files[0])
      reader.addEventListener('load' , () => {
        // imageControl.setValue(reader.result)
        resolve(reader.result)
      })
   })
  }
}