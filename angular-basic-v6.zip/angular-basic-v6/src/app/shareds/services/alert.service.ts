import { Injectable } from "@angular/core";

declare const $: any;
declare const swal: any;
@Injectable()
export class AlertService {
    notify(message: string , type : string) {
        $.notify({

            title: "Alert : ",
            message: message,
            icon: 'fa fa-check'
        }, {

            type: type,
            allow_dismiss: true,
            newest_on_top: false,
            mouse_over: 'pause',
            showProgressbar: false,
            placement: {
                from: "top",
                align: "right"
            },
            delay: 5000,
            timer: 1000,
            animate: {
                enter: 'animated fadeInDown',
                exit: 'animated fadeOutUp'
            },
            icon_type: 'class'
        });

    }

    fillTheblank(message: string = "please fill the blank") {
        $.notify({

            title: "Warning!! : ",
            message: message,
            icon: 'fa fa-check'
        }, {

            type: "warning",
            allow_dismiss: true,
            newest_on_top: false,
            mouse_over: 'pause',
            showProgressbar: false,
            placement: {
                from: "top",
                align: "right"
            },
            delay: 5000,
            timer: 1000,
            animate: {
                enter: 'animated fadeInDown',
                exit: 'animated fadeOutUp'
            },
            icon_type: 'class'
        });

    }


    alertConfirm(message : string = "Do you want to delete this information"): Promise<any>{
       return swal(message , { buttons : ["cancel" , "confirm"] , dangerMode : true});
    }
}