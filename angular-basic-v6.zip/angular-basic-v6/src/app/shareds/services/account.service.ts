import { Injectable } from "@angular/core";
import { ResolveEnd } from "@angular/router";
import { IChangePassword } from "src/app/authentication/components/profile/change-password/change-password.interface";
import { IProfile } from "src/app/authentication/components/profile/profile.interface";
import { ILogin } from "src/app/components/login/login.interface";
import { IRegister } from "src/app/components/register/register.interface";
import { HttpService } from "src/app/services/http.service";
import { resolve } from "url";

@Injectable({
    providedIn : "root"
})

export class AccountService {

    constructor(
        private http : HttpService
    ){}

    public mockUserItem: IAccount[] = [
        {
            id: 1,
            firstname: "John",
            lastname: "Doe",
            email: "johnDoe@gmail.com",
            password: "123456",
            position: "Frontend Developer",
            role : IRoleAccount.Admin,
            image: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
            created: new Date(),
            updated: new Date()
        },
        {
            id: 2,
            firstname: "Poonnawit",
            lastname: "Poosakul",
            email: "pp@gmail.com",
            password: "123456",
            position: "Backend Developer",
            role : IRoleAccount.Employee,
            image: null,
            created: new Date(),
            updated: new Date()
        }
        ,
        {
            id: 3,
            firstname: "Mem",
            lastname: "member",
            email: "member@gmail.com",
            password: "123456",
            position: "Backend Developer",
            role : IRoleAccount.Member,
            image: null,
            created: new Date(),
            updated: new Date()
        }
    ]

    public UserLogin : IAccount = {} as any;

    public setUserLogin(userLogin : IAccount) {
        this.UserLogin.id = userLogin.id;
        this.UserLogin.firstname = userLogin.firstname;
        this.UserLogin.lastname = userLogin.lastname;
        this.UserLogin.email = userLogin.email;
        this.UserLogin.password = userLogin.password;
        this.UserLogin.image = userLogin.image;
        this.UserLogin.position = userLogin.position;
        this.UserLogin.role = userLogin.role;
        this.UserLogin.created = userLogin.created;
        this.UserLogin.updated = userLogin.updated;
        return this.UserLogin;
    }

    onChangePassword(accessToken : string , model : IChangePassword) {
        // return new Promise((resolve , reject)=> {
        //     const userProfile = this.mockUserItem.find( u => u.id == accessToken);
        //     if(!userProfile) return reject({Message : "Not Found User"});
        //     if(userProfile.password !== model.oldPassword) return reject({Message : "Password Invalid"})
        //     userProfile.password = model.newPassword;
        //     userProfile.updated = new Date();
                model['old_pass']  = model.oldPassword
                model['new_pass']  = model.newPassword
        //     console.log(userProfile)
        //     resolve(userProfile)
      
        // })

        return this.http.requestPost('api/member/change-password' , model , accessToken)
        .toPromise() as Promise<IAccount>
    }

    getUserLogin(accessToken: string) {
        // return new Promise<IAccount>((resolve, reject) => {
        //     console.log("Mock Data")
        //     console.log(this.mockUserItem)
        //     const userLogin = this.mockUserItem.find(u => u.id == accessToken);
        //     if (!userLogin) return reject({ Message: " AccessToken Invalid" });
        //     resolve(userLogin);
        // })

       return (this.http.requestGet("api/member/data" , accessToken)
        .toPromise() as Promise<IAccount>)
        .then(user => this.setUserLogin(user))
    }

    onLogin(model: ILogin) {
        // return new Promise<{ accessToken: string }>((resolve, reject) => {

        //     const userLogin = this.mockUserItem.find(u => u.email == model.email && u.password == model.password)

        //     if (!userLogin) {
        //         return reject({ Message: "Email or Password Invalid" })
        //     }

        //     resolve({
        //         accessToken: userLogin.id
        //     });


        // })

         return this.http.requestPost('api/account/login', model)
                        .toPromise() as Promise<{accessToken : string}>;
    }

    onRegister(model: IRegister) {
        // model['id'] = Math.random(); 
        // const _model : IAccount = model
        model['cpassword'] = model.confirmPassword
        // _model.position = "";
        // _model.image = null;
        // _model.role = IRoleAccount.Member;
        // _model.created = new Date()
        // _model.updated = new Date()
        // this.mockUserItem.push(model)
     
        // return new Promise((resolve, reject) => {
        //     // console.log(model)
        //     resolve(model);
        // })
      

        return this.http.requestPost('api/account/register', model)
                        .toPromise() as Promise<IAccount>;
    }


    updateProfile(accessToken: string, model: IProfile) {
        // return new Promise((resolve, reject) => {
        //     const userProfile = this.mockUserItem.find(u => u.id == asccessToken)

        //     if (!userProfile) return reject({ Message: "Not Found User" })

        //     userProfile.firstname = model.firstname;
        //     userProfile.lastname = model.lastname;
        //     userProfile.position = model.position;
        //     userProfile.image = model.image;
        //     userProfile.updated = new Date()

        //     resolve(userProfile)
        // })

        return (this.http.requestPost("api/member/profile" , model , accessToken)
        .toPromise() as Promise<IAccount>)
        .then( u => this.setUserLogin(u))
    }
}


export interface IAccount {
    firstname: string;
    lastname: string;
    email: string;
    password: string;

    id?: any;
    position?: string;
    role? : IRoleAccount
    image?: string;
    created?: Date,
    updated?: Date
}

export enum IRoleAccount {
    Member = 1,
    Employee,
    Admin
}