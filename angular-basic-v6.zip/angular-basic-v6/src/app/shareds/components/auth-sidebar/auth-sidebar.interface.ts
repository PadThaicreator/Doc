import { IAccount, IRoleAccount } from "../../services/account.service";

export interface IAuthSidebarComponent {
    AppUrl : any;
    AuthUrl : any;
    UserLogin : IAccount;
    Role : typeof IRoleAccount
}