import { Component, Input, OnInit } from '@angular/core';
import { IChangePasswordComponent } from './change-password.interface';
import { BsModalRef } from 'ngx-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertService } from 'src/app/shareds/services/alert.service';
import { ValidatorsService } from 'src/app/shareds/services/validator.service';
import { AccountService } from 'src/app/shareds/services/account.service';
import { AuthenService } from 'src/app/services/authen.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements IChangePasswordComponent {

  constructor(
    private builder: FormBuilder,
    private alert: AlertService,
    private validator: ValidatorsService,
    private account: AccountService,
    private authen: AuthenService
  ) {
    this.initialCreateFormData()
  }

  @Input('modalRef') modalRef: BsModalRef;

  form: FormGroup;

  onSubmit(): void {

    if (this.form.invalid) return this.alert.fillTheblank()

    this.account.onChangePassword(this.authen.getAuthentication(), this.form.value)
      .then(user => {
        this.alert.notify("Update Password Success", "info")
        this.modalRef.hide()
      })
      .catch(err => this.alert.notify(err.Message, "warning"))
  }

  private initialCreateFormData() {
    this.form = this.builder.group({
      oldPassword: ["", Validators.required],
      newPassword: ["", [Validators.required, this.validator.isPassword]],
      confirmNewPassword: ["", [Validators.required, this.validator.comparePassword("newPassword")]]
    })
  }

}
