import { Component, OnInit, TemplateRef } from '@angular/core';
import { IProfileComponent } from './profile.interface';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenService } from 'src/app/services/authen.service';
import { AccountService } from 'src/app/shareds/services/account.service';
import { AlertService } from 'src/app/shareds/services/alert.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { SharedsService } from 'src/app/shareds/services/shareds.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements IProfileComponent {

  constructor(
    private builder : FormBuilder,
    private authen : AuthenService,
    private account : AccountService,
    private alert : AlertService,
    private modalService : BsModalService,
    private sharedService : SharedsService
  ) {

    this.initialCreateData();
    this.initialLoadData();
    this.positionItem = this.sharedService.positionItem;
   }

  positionItem: any[] = [] ;

  form : FormGroup;
  modalRef: BsModalRef;
  onSubmit(): void {

    if(this.form.invalid) return this.alert.fillTheblank();
    this.account.updateProfile(this.authen.getAuthentication() , this.form.value )
    .then(()=> this.alert.notify("Update Success" , "success"))
    .catch( err => this.alert.notify(err.Message , "warning"))
  }

  onConvertImage(input : HTMLInputElement) {
    const imageControl = this.form.controls['image'];


    this.sharedService.onConvertImage(input)
    .then( res => {
        imageControl.setValue(res)
    })
    .catch(err => {
          imageControl.setValue(null)
         input.value = null;
        this.alert.notify(err.Message , "warning")
    })
    
    // imageControl.setValue( null) 
    // if(input.files.length == 0) return ;

    // if(imageType.indexOf(input.files[0].type) < 0){
    //   input.value = null;
    //   return this.alert.notify("Please upload only image" , "warning")
    // }
    //   console.log(input)
    //   const reader = new FileReader();

    //   reader.readAsDataURL(input.files[0])
    //   reader.addEventListener('load' , () => {
    //     imageControl.setValue(reader.result)
    //   })
  }


  openModal(template: TemplateRef<any>) {
    // console.log(template)
    this.modalRef = this.modalService.show(template)
  }
  private initialCreateData() {
    this.form = this.builder.group({
      email : ['' , Validators.required],
      firstname : ['', Validators.required],
      lastname : ['', Validators.required],
      position : ['', Validators.required],
      image : [null]
    }),
    this.form.get("email").disable()
  }

  private initialLoadData() {
    this.account.getUserLogin(this.authen.getAuthentication())
    .then(res =>{
        this.form.controls['email'].setValue(res.email)
        this.form.controls['firstname'].setValue(res.firstname)
        this.form.controls['lastname'].setValue(res.lastname)
        this.form.controls['image'].setValue(res.image)
        this.form.controls['position'].setValue(res.position)
    })
    .catch(err => {
      this.alert.notify(err.Message , "warning")
    })
  }
}
