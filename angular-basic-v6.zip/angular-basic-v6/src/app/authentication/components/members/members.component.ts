import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MemberService } from '../../serivce/member.service';
import { IMember, IMembersComponent, IMemberSeacrh, IMemberSearchKey } from './member.interface';
import { AccountService, IAccount, IRoleAccount } from 'src/app/shareds/services/account.service';
import { AlertService } from 'src/app/shareds/services/alert.service';
import { BsLocaleService, PageChangedEvent } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { AppURL } from 'src/app/app.url';
import { AuthURL } from '../../authentication.url';
import { AuthenService } from 'src/app/services/authen.service';
@Component({
  selector: 'app-members',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css'],
  // providers : [MemberService]
})
export class MembersComponent implements  IMembersComponent {

  constructor(
    private member : MemberService,
    private alert : AlertService,
    private detect : ChangeDetectorRef,
    private router : Router,
    private localService : BsLocaleService,
    private account : AccountService,
    private authen : AuthenService
  ) {

    this.localService.use('en')
    this.initialLoadMember({
      startPage : this.startPage,
      limitPage : this.limitPage
    })

    this.searchType = this.searchTypeItems[0]
    this.initialLoadUserLogin();
   }

    items: IMember ;

  //Load Member Data

  private initialLoadMember(option? : IMemberSeacrh){
    this.member.getMembers(option)
    .then(res => {
      
      this.items = res;
    })
    .catch(err => this.alert.notify("Cannot Load Member Data" , "warning"))
  }
  
  
  getRoleUser(role: IRoleAccount): string {
    return IRoleAccount[role]
  }

  onDelete(item: IAccount): void {
    const messageAlert = `Do you want to delete ${item.email} ?`
   this.alert.alertConfirm(messageAlert)
   .then( status => {
      if(!status) return;

      this.member.deleteMember(item.id)
      .then(res => {
        this.initialLoadMember({
          searchText :  this.getSearchText,
          searchType : this.searchType.key,
          startPage : this.startPage,
          limitPage : this.limitPage
        })
      
        this.alert.notify("Delete Success"  , "success")
      })
      .catch(err => this.alert.notify(err.Message , "warning"))

   })
  }


  editMember(item: IAccount): void {
      this.router.navigate(["/" , AppURL.Authen , AuthURL.CreateMember , item.id])  // Follow Path /:id
      // this.router.navigate(["/" , AppURL.Authen , AuthURL.CreateMember , {id : item.id}]) // ;id = 1
      // this.router.navigate(["/" , AppURL.Authen , AuthURL.CreateMember] , {queryParams : { id : item.id}}) // ?id = 1
  }
  
  searchText: string = "";
  searchType: IMemberSearchKey;
  searchTypeItems: IMemberSearchKey[] = [
    { key : 'email' , value : 'search by Email'},
    { key : 'firstname' , value : 'search by Firstname'},
    { key : 'lastname' , value : 'search by Lastname'},
    { key : 'position' , value : 'search by Position'},
    { key : 'role' , value : 'search by Privilege'},
    { key : 'updated' , value : 'search by Date'},
  ];

  limitPage: number = 10;
  startPage: number = 1;


  UserLogin: IAccount;
  Role = IRoleAccount;
  onPageChange(page: PageChangedEvent) {
    this.initialLoadMember({
      searchText : this.getSearchText,
      searchType : this.searchType.key,
      startPage : page.page,
      limitPage : page.itemsPerPage
    })
  }


  onSearchItem(): void {
    this.startPage = 1;
    this.initialLoadMember({
      searchText : this.getSearchText,
      searchType : this.searchType.key,
      startPage : this.startPage,
      limitPage : this.limitPage
    })

    this.detect.detectChanges();
  }


// if use get It will see like OBJ
  private get getSearchText() {

    let responseSearchText = null

    switch(this.searchType.key){
        case "role" : responseSearchText =  IRoleAccount[this.searchText];
              break;
        case "updated" :
          const searchDate : {from : Date , to :Date} = { from : new Date(this.searchText[0]) , to : new Date(this.searchText[1])}
              searchDate.from.setHours(0);
              searchDate.from.setMinutes(0);
              searchDate.from.setSeconds(0);

              searchDate.to.setHours(23);
              searchDate.to.setMinutes(59);
              searchDate.to.setSeconds(59);
              responseSearchText = searchDate;
          break;
        default : responseSearchText = this.searchText
              break;
        }

        return responseSearchText;
  }


  private initialLoadUserLogin(){
      this.account.getUserLogin(this.authen.getAuthentication())
      .then( res => {
        this.UserLogin = res
      })
      .catch (err => {
        this.alert.notify("Login Error" , "warning")
      })
  }
}
