import { Component, OnInit } from '@angular/core';
import { IMemberCreateComponent } from './member-create.interface';
import { IRoleAccount } from 'src/app/shareds/services/account.service';
import { SharedsService } from 'src/app/shareds/services/shareds.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidatorsService } from 'src/app/shareds/services/validator.service';
import { AlertService } from 'src/app/shareds/services/alert.service';
import { MemberService } from '../../serivce/member.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AppURL } from 'src/app/app.url';
import { AuthURL } from '../../authentication.url';

@Component({
  selector: 'app-member-create',
  templateUrl: './member-create.component.html',
  styleUrls: ['./member-create.component.css']
})
export class MemberCreateComponent implements IMemberCreateComponent {

  constructor(
    private shardsService: SharedsService,
    private builder: FormBuilder,
    private validator : ValidatorsService,
    private alert : AlertService,
    private member : MemberService,
    private router : Router,
    private activatedRouter : ActivatedRoute
  ) {
    // this.activatedRouter.queryParams.forEach( q => {
    //   console.log(q)
    // })

    // this.activatedRouter.snapshot.queryParams;

     this.activatedRouter.params.forEach( p => {
       this.memId = p.id;
    })
    this.initialFormData();
    this.updateFormData();
    this.positionItems = this.shardsService.positionItem
  }
  memId: any;
  positionItems: string[] = [];
  // roleitems is number
  roleItems: IRoleAccount[] = [
    IRoleAccount.Member,
    IRoleAccount.Employee,
    IRoleAccount.Admin
  ];
  // change num to string
  getRoleName(role: IRoleAccount): string {
    return IRoleAccount[role]
  }


  form: FormGroup;

  onSave(): void {

    if(this.form.invalid) return this.alert.notify("Please check your information" , "warning")
      // console.log(this.form.value)
    if(!this.memId){
      this.member.createMember(this.form.value)
    .then(res => {
       this.alert.notify("Add Member Success" , "success")
       this.router.navigate(['/' , AppURL.Authen , AuthURL.AllMembers])
    })
    .catch(err=>{
        this.alert.notify(err.Message , "warning")
    })
    }else{
         this.member.updateMember(this.memId , this.form.value)
        .then(res=>{
            this.alert.notify("Update Member Success" , "success")
            this.router.navigate(['/' , AppURL.Authen , AuthURL.AllMembers])
        })
        .catch(err => this.alert.notify(err.Message , "warning"))
    }
  }

  onConvertImage(input: HTMLInputElement) {
    const imageControl = this.form.controls['image']
    this.shardsService.onConvertImage(input)
      .then(res => {
          imageControl.setValue(res)
      })
      .catch(err => {
        input.value = null
            imageControl.setValue(null)
        this.alert.notify(err.Message , "warning")
      })
  }

  private initialFormData() {
    this.form = this.builder.group({
      email: ["", [Validators.required , Validators.email]],
      password: ["", [Validators.required ,this.validator.isPassword] ],
      firstname: ["", Validators.required],
      lastname: ["", Validators.required],
      position: ["", Validators.required],
      role: ["", Validators.required],
      image : [""]
    })
  }


    private updateFormData() {
        if(!this.memId)  return;

        this.member.getMemberById(this.memId)
        .then(res => {
          // console.log("update form")
          // console.log(res)
          const form = this.form;
          form.controls['image'].setValue(res.image);
          form.controls['firstname'].setValue(res.firstname);
          form.controls['lastname'].setValue(res.lastname);
          form.controls['role'].setValue(res.role);
          form.controls['position'].setValue(res.position);
          // form.controls['password'].setValue(res.password);
          form.controls['email'].setValue(res.email);
          form.controls['password'].setValidators(this.validator.isPassword);
          form.controls['password'].updateValueAndValidity();
        })
        .catch(err => {
          this.alert.notify(err.Message , "warning")
          this.router.navigate(['/' , AppURL.Authen , AuthURL.AllMembers])
        })
    }
}
