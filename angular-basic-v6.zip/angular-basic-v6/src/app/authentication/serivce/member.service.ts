import { Injectable } from "@angular/core";
import { AccountService, IAccount, IRoleAccount } from "src/app/shareds/services/account.service";
import { IMember, IMemberSeacrh } from "../components/members/member.interface";
import { HttpService } from "src/app/services/http.service";
import { AuthenService } from "src/app/services/authen.service";


declare let $;
@Injectable()

export class MemberService {
    constructor(
        private account: AccountService,
        private http : HttpService,
        private authen : AuthenService
    ) {
        
        // this.generateMembers();
    }


    getMembers(options?: IMemberSeacrh) {
        // const startItem = (options.startPage - 1) * options.limitPage;
        // const endItem = options.startPage * options.limitPage;
        // return new Promise<IMember>((resolve, reject) => {

        //     let items = this.account.mockUserItem.sort((a1,a2)=>{
        //         return Date.parse(a2.updated.toString() )- Date.parse(a1.updated.toString())
        //     })
        //     if (options && options.searchText && options.searchType) {
        //         items = this.account.mockUserItem.filter(item =>{
        //             switch (options.searchType){
        //                 case 'updated' : 
        //                     return item.updated >= options.searchText['from'] && item.updated <= options.searchText['to'];
        //                 default :
        //                     return  item[options.searchType].toString().toLowerCase()
        //             .indexOf(options.searchText.toString().toLowerCase()) >= 0
                          
        //             }
        //         }
        //         );
        //     }
        //     resolve({
        //         items : items.slice(startItem , endItem) ,
        //         totalItems : items.length
        //     })
        // })
        return this.http.requestGet(`api/member?${$.param(options)}` , this.authen.getAuthentication())
        .toPromise() as Promise<IMember>
    }

    getMemberById(id : any) {
        // return new Promise<IAccount> ((resolve , reject) => {
        //     const member = this.account.mockUserItem.find( m => m.id == id);
        //     if(!member) return reject({Message : "Member Not Found"});

        //     return resolve(member);
        // })

        return this.http.requestGet(`api/member/${id}` , this.authen.getAuthentication())
                        .toPromise() as Promise <IAccount>
    }

    createMember(model : IAccount) {
        // return new Promise<IAccount>((resolve , reject) => {

        //     if(this.account.mockUserItem.find( u => u.email == model.email)){
        //         return reject({Message : "Email already exists"})
        //     }
        //     model.id = Math.random();
        //     model.created = new Date();
        //     model.updated = new Date();
        //     this.account.mockUserItem.push(model);
        //     resolve(model)
        // })

        return this.http.requestPost('api/member' , model , this.authen.getAuthentication())
                        .toPromise() as Promise<IAccount>
    }

    deleteMember(id : any){
       
        // return new Promise((resolve , reject)=> {
        //     const findIndex  = this.account.mockUserItem.findIndex( m => m.id == id);
        //     if(findIndex < 0) return reject({Message : "Not Found Member"})
                
        //     resolve(this.account.mockUserItem.splice(findIndex , 1 ))
        
        // })

        return this.http.requestDelete(`api/member/${id}` , this.authen.getAuthentication())
        .toPromise() as Promise<number>
    }

    updateMember(id : any ,model : IAccount){
        // return new Promise((resolve , reject)=>{
        //     const member = this.account.mockUserItem.find(m => m.id ==id)
        //     if(!member) return reject({Message : "Member Nout Found"})
                
        //        const existEmail = this.account.mockUserItem.find(m => model.email == m.email);
               
        //        if(existEmail && existEmail.id != id) return reject({Message : "Email already Exist"})
        //         member.image = model.image
        //         member.email = model.email
        //         member.firstname = model.firstname
        //         member.lastname = model.lastname
        //         member.role = model.role
        //         member.position = model.position
        //         member.password = model.password || member.password
        //         member.updated = new Date()

        //         resolve(member)
        //     })

        return this.http.requestPut(`api/member/${id}` , model , this.authen.getAuthentication())
                        .toPromise() as Promise<IAccount>
    }

    // จำลองข้อมูลสมาชิก เพื่อทำ pagination
    // private generateMembers() {
    //     const positions = ['Frontend Developer', 'Backend Developer'];
    //     const roles = [IRoleAccount.Member, IRoleAccount.Employee, IRoleAccount.Admin];
    //     // this.account.mockUserItem.splice(2)
    //     for (let i = 3; i <= 333; i++)
    //         this.account.mockUserItem.push({
    //             id: i.toString(),
    //             firstname: `Firstname ${i}`,
    //             lastname: `Lastname ${i}`,
    //             email: `mail-${i}@mail.com`,
    //             password: '123456',
    //             position: positions[Math.round(Math.random() * 1)],
    //             role: roles[Math.round(Math.random() * 2)],
    //             created : new Date(),
    //             updated : new Date(2018 , 4 , Math.round(Math.random() *24 + 1))
    //         });
    // }
}