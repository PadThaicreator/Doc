import {Routes , RouterModule} from '@angular/router'
import { AuthURL } from './authentication.url';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SettingComponent } from './components/setting/setting.component';
import { ProfileComponent } from './components/profile/profile.component';
import { BootstrapElementsComponent } from './components/bootstrap-elements/bootstrap-elements.component';
import { CardsComponent } from './components/cards/cards.component';
import { WidgetsComponent } from './components/widgets/widgets.component';
import { MembersComponent } from './components/members/members.component';
import { Component } from '@angular/core';
import { createComponent } from '@angular/compiler/src/core';
import { MemberCreateComponent } from './components/member-create/member-create.component';
import { UserRoleGuard } from '../guards/user-role.guard';
import { IRoleAccount } from '../shareds/services/account.service';

const RoutesLists:Routes = [
    {
        path : AuthURL.Dashboard,
        component : DashboardComponent,
        canActivate : [UserRoleGuard],
        data : { role : [IRoleAccount.Admin, IRoleAccount.Employee]}
    },
    {
        path : AuthURL.Setting,
        component : SettingComponent
    },
    {
        path : AuthURL.Profile,
        component : ProfileComponent
    },
    {
        path : AuthURL.Element ,
        component : BootstrapElementsComponent
    },
    {
        path : AuthURL.Card,
        component:CardsComponent
    },
    {
        path : AuthURL.Widget,
        component : WidgetsComponent
    },
    {
        path : AuthURL.AllMembers,
        component : MembersComponent,
        canActivate : [UserRoleGuard],
        data : { role : [IRoleAccount.Admin , IRoleAccount.Employee]}
    },
    {
        path : AuthURL.CreateMember ,
        canActivate : [UserRoleGuard],
        data : { role : [IRoleAccount.Admin]},
        children : [
            {path : "" , component : MemberCreateComponent},
            {path : ":id" , component : MemberCreateComponent}
        ]
    },
    {
        path : "",
        redirectTo : AuthURL.Profile,
        pathMatch : 'full'
    }
];

export const AuthenticationRouting = RouterModule.forChild(RoutesLists);