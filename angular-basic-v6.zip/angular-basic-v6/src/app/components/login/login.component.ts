import { Component, OnInit } from '@angular/core';
import { AppURL } from 'src/app/app.url';
import { ILoginComponent } from './login.interface';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertService } from 'src/app/shareds/services/alert.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthURL } from 'src/app/authentication/authentication.url';
import { AccountService } from 'src/app/shareds/services/account.service';
import { AuthenService } from 'src/app/services/authen.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements ILoginComponent {

  constructor(
    private builder : FormBuilder,
    private alert : AlertService,
    private router : Router,
    private account  : AccountService,
    private authen : AuthenService,
    private activateRoute : ActivatedRoute
  ) { 

    this.activateRoute.params.forEach(params => {
        this.returnURL = params.returnURL || `/${AppURL.Authen}` ; 
    })
    this.initialCreateFormData();
  }
  returnURL: string;
  Url = AppURL
  form: FormGroup;
  onSubmit(): void {
    if(this.form.invalid) return this.alert.fillTheblank()
    console.log(this.form.value)

    this.account.onLogin(this.form.value)
    .then(res => {
      console.log(res)
      this.authen.setAuthentication(res.accessToken);
      this.alert.notify("Login Success" , "success")
       this.router.navigateByUrl(this.returnURL)
    })
    .catch(err => this.alert.notify(err.Message , "warning") )
   
  }

  test = ""

  private initialCreateFormData() {
    this.form = this.builder.group({
      email : ["",Validators.required],
      password : ["",Validators.required],
      remember : [true]
    })
  }
 
}
