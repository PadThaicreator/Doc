import { Component, OnInit } from '@angular/core';
import { AppURL } from 'src/app/app.url';
import { IRegisterComponent } from './register.interface';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertService } from 'src/app/shareds/services/alert.service';
import { AccountService } from 'src/app/shareds/services/account.service';
import { Router } from '@angular/router';
import { ValidatorsService } from 'src/app/shareds/services/validator.service';
declare const $;
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements IRegisterComponent {

  constructor(
    private builder: FormBuilder,
    private alert : AlertService,
     private account : AccountService,
     private router : Router,
    private validators : ValidatorsService
    
    ) {
    this.initialCreateFormData();
   
  }

  form: FormGroup;
  Url = AppURL;
  onSubmit() {

    if (this.form.invalid) return this.alert.fillTheblank();
      // this.account.onRegister(this.form.value)
      // .then(res => {

      //   this.alert.notify("Register Success" , "info")
      //   this.router.navigate(['/' , AppURL.Login])
      
      // })
      // .catch(err => this.alert.notify(err.Message , "warning"))

    

  }

  ALERT(){
    alert("SADSD")
  }

  

  private initialCreateFormData() {
    this.form = this.builder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      email: ['', [Validators.required , Validators.email]],
      password: ['',[ Validators.required,this.validators.isPassword]],
      confirmPassword: ['', [Validators.required , this.validators.comparePassword('password')]]
    });
  }


  // create Validate

  
}
