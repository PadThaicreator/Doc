export const AppURL = {
    Login : 'login',
    Register : 'register',
    Authen: 'auth'
}