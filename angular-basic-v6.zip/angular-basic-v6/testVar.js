
const v = {
    name : "namo"
}

console.log(v);


const c = v;

console.log(c)

c.name = "John"
console.log(c)
console.log(v);