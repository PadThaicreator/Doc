"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const app_interface_1 = require("./app.interface");
const crypto_1 = require("crypto");
const app_classes_1 = require("./app.classes");
const config_1 = require("./config");
let AppService = class AppService {
    constructor() {
        this.UserItems = [
            {
                id: 1,
                firstname: 'Member',
                lastname: 'Member',
                email: 'member@server.com',
                password: this.HashPassword('123456'),
                position: 'Frontend Developer',
                image: null,
                role: app_interface_1.IRoleAccount.Member,
                created: new Date(2018, 4, 26),
                updated: new Date(2018, 4, 26)
            },
            {
                id: 2,
                firstname: 'Employee',
                lastname: 'Employee',
                email: 'employee@server.com',
                password: this.HashPassword('123456'),
                position: 'Backend Developer',
                image: null,
                role: app_interface_1.IRoleAccount.Employee,
                created: new Date(2018, 4, 25),
                updated: new Date(2018, 4, 25)
            },
            {
                id: 3,
                firstname: 'Admin',
                lastname: 'Admin',
                email: 'admin@server.com',
                password: this.HashPassword('123456'),
                position: 'Frontend Developer',
                image: null,
                role: app_interface_1.IRoleAccount.Admin,
                created: new Date(2018, 4, 24),
                updated: new Date(2018, 4, 24)
            }
        ];
        if (config_1.config.generate_members)
            this.generateMembers();
    }
    HashPassword(password) {
        const sha1 = crypto_1.createHash('sha1');
        return sha1.update(password).digest('hex');
    }
    getItemAll() {
        return this.UserItems;
    }
    getItems(options) {
        const rowsItems = this.UserItems.sort((item1, item2) => Date.parse(item2.updated.toString()) - Date.parse(item1.updated.toString()));
        let returnItems = rowsItems;
        const startPage = (options.startPage - 1) * options.limitPage;
        const endPage = options.startPage * options.limitPage;
        if (options && options.searchType && options.searchText) {
            returnItems = rowsItems.filter(item => {
                switch (options.searchType) {
                    case 'updated':
                        return item.updated >= new Date(options.searchText['from']) && item.updated <= new Date(options.searchText['to']);
                    default:
                        return item[options.searchType].toString().toLowerCase()
                            .indexOf(options.searchText.toString().toLowerCase()) >= 0;
                }
            });
        }
        return {
            items: returnItems.slice(startPage, endPage),
            totalItems: returnItems.length
        };
    }
    getItemById(id) {
        return this.UserItems.find(item => item.id == id);
    }
    createItem(value) {
        if (this.UserItems.find(item => item.email == value.email))
            throw new common_1.BadRequestException('อีเมล์นี้มีในระบบแล้ว');
        const model = new app_classes_1.CreateAccount();
        model.id = Math.max.apply(this, this.UserItems.map(m => m.id)) + 1;
        model.firstname = value.firstname;
        model.lastname = value.lastname;
        model.email = value.email;
        model.password = this.HashPassword(value.password);
        model.image = '';
        model.position = value.position;
        model.role = value.role;
        model.created = new Date();
        model.updated = new Date();
        this.UserItems.push(model);
        return model;
    }
    updateItem(id, value) {
        const findUser = this.UserItems.find(item => item.id == id);
        if (!findUser)
            throw new common_1.BadRequestException('ไม่มีข้อมูลในระบบ');
        if (this.UserItems.find(item => {
            return item.email == value.email && value.email != findUser.email;
        }))
            throw new common_1.BadRequestException('อีเมล์นี้มีในระบบแล้ว');
        findUser.email = value.email;
        findUser.password = value.password ? this.HashPassword(value.password) : findUser.password;
        findUser.firstname = value.firstname;
        findUser.lastname = value.lastname;
        findUser.position = value.position;
        findUser.role = value.role;
        findUser.image = value.image;
        findUser.updated = new Date();
        return findUser;
    }
    deleteItem(id) {
        const findIndex = this.UserItems.findIndex(item => item.id == id);
        if (findIndex < 0)
            throw new common_1.BadRequestException('ไม่มีข้อมูลในระบบ');
        return this.UserItems.splice(findIndex, 1);
    }
    postRegister(value) {
        const model = new AccountRegister();
        model.id = Math.max.apply(this, this.UserItems.map(m => m.id)) + 1;
        model.firstname = value.firstname;
        model.lastname = value.lastname;
        model.email = value.email;
        model.password = this.HashPassword(value.password);
        model.image = '';
        model.position = '';
        model.role = app_interface_1.IRoleAccount.Member;
        model.created = new Date();
        model.updated = new Date();
        this.UserItems.push(model);
        return model;
    }
    postLogin(value) {
        return this.UserItems.find(item => {
            return item.email == value.email && item.password == this.HashPassword(value.password);
        });
    }
    postUpdateProfile(id, value) {
        const updateProfile = this.UserItems.find(item => item.id == id);
        if (!updateProfile)
            throw new common_1.BadRequestException('ไม่มีข้อมูลนี้ในระบบ');
        updateProfile.firstname = value.firstname;
        updateProfile.lastname = value.lastname;
        updateProfile.image = value.image;
        updateProfile.position = value.position;
        updateProfile.updated = new Date();
        return updateProfile;
    }
    postChangePassword(id, value) {
        const userProfile = this.UserItems.find(item => item.id == id);
        if (!userProfile)
            throw new common_1.BadRequestException('ไม่มีข้อมูลในระบบ');
        if (userProfile.password != this.HashPassword(value.old_pass))
            throw new common_1.BadRequestException('รหัสผ่านเดิมไม่ถูกต้อง');
        userProfile.password = this.HashPassword(value.new_pass);
        userProfile.updated = new Date();
        return userProfile;
    }
    generateMembers() {
        const positions = ['Frontend Developer', 'Backend Developer'];
        const roles = [app_interface_1.IRoleAccount.Member, app_interface_1.IRoleAccount.Employee, app_interface_1.IRoleAccount.Admin];
        for (let i = 3; i <= 9999; i++) {
            const setDate = new Date(config_1.config.year, config_1.config.month - 1, Math.round(Math.random() * (config_1.config.date_end - 1) + config_1.config.date_start));
            this.UserItems.push({
                id: i.toString(),
                firstname: `Firstname ${i}`,
                lastname: `Lastname ${i}`,
                email: `mail-${i}@mail.com`,
                password: '123456',
                position: positions[Math.round(Math.random() * 1)],
                role: roles[Math.round(Math.random() * 2)],
                created: setDate,
                updated: setDate
            });
        }
    }
};
AppService = __decorate([
    common_1.Injectable(),
    __metadata("design:paramtypes", [])
], AppService);
exports.AppService = AppService;
class AccountRegister {
}
exports.AccountRegister = AccountRegister;
//# sourceMappingURL=app.service.js.map