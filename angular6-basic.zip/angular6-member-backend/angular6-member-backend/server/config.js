"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    generate_members: true,
    year: 2018,
    month: 4,
    date_start: 1,
    date_end: 60
};
//# sourceMappingURL=config.js.map