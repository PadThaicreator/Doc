import { IAccount, IRoleAccount, ISearch, IMember, IRegister, ILogin, IProfile, IChangePassword } from './app.interface';
export declare class AppService {
    constructor();
    private HashPassword(password);
    private UserItems;
    getItemAll(): IAccount[];
    getItems(options?: ISearch): IMember;
    getItemById(id: any): IAccount;
    createItem(value: IAccount): IAccount;
    updateItem(id: any, value: IAccount): IAccount;
    deleteItem(id: any): IAccount[];
    postRegister(value: IRegister): IAccount;
    postLogin(value: ILogin): IAccount;
    postUpdateProfile(id: any, value: IProfile): IAccount;
    postChangePassword(id: any, value: IChangePassword): IAccount;
    private generateMembers();
}
export declare class AccountRegister implements IAccount {
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    id?: any;
    position?: string;
    image?: string;
    role?: IRoleAccount;
    created?: Date;
    updated?: Date;
}
