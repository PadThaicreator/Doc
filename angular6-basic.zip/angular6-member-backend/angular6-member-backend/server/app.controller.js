"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const app_service_1 = require("./app.service");
class AppSchema {
    constructor(route, desc, method) {
        this.route = route;
        this.description = desc;
        this.method = method;
    }
}
exports.AppSchema = AppSchema;
let AppController = class AppController {
    constructor(app) {
        this.app = app;
    }
    appRoot() {
        const schemars = [
            new AppSchema('api/account/register', 'สมัครสมาชิก', 'POST'),
            new AppSchema('api/account/login', 'เข้าสู่ระบบ', 'POST'),
            new AppSchema('api/member/data', 'ข้อมูลผู้ใช้ที่เข้าสู่ระบบ', 'GET'),
            new AppSchema('api/member/profile', 'แก้ไขข้อมูลไปรไฟล์', 'POST'),
            new AppSchema('api/member/change-password', 'เปลี่ยนรหัสผ่าน', 'POST'),
            new AppSchema('api/member', 'รายการสมาชิกหลายคน', 'GET'),
            new AppSchema('api/member/:id', 'รายการสมาชิกคนเดียว', 'GET'),
            new AppSchema('api/member', 'เพิ่มสมาชิกใหม่', 'POST'),
            new AppSchema('api/member/:id', 'แก้ไขสมาชิก', 'PUT'),
            new AppSchema('api/member/:id', 'ลบสมาชิก', 'DELETE'),
        ];
        return schemars;
    }
    example() {
        const items = this.app.getItemAll();
        return items.sort((a, b) => Date.parse(b.updated.toString()) - Date.parse(a.updated.toString()));
    }
};
__decorate([
    common_1.Get(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AppController.prototype, "appRoot", null);
__decorate([
    common_1.Get('example'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Array)
], AppController.prototype, "example", null);
AppController = __decorate([
    common_1.Controller(),
    __metadata("design:paramtypes", [app_service_1.AppService])
], AppController);
exports.AppController = AppController;
//# sourceMappingURL=app.controller.js.map