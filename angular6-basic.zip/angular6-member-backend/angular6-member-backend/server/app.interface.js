"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var IRoleAccount;
(function (IRoleAccount) {
    IRoleAccount[IRoleAccount["Member"] = 1] = "Member";
    IRoleAccount[IRoleAccount["Employee"] = 2] = "Employee";
    IRoleAccount[IRoleAccount["Admin"] = 3] = "Admin";
})(IRoleAccount = exports.IRoleAccount || (exports.IRoleAccount = {}));
//# sourceMappingURL=app.interface.js.map