export declare const config: {
    generate_members: boolean;
    year: number;
    month: number;
    date_start: number;
    date_end: number;
};
