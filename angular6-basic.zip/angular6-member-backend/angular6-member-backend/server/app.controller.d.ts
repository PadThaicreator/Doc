import { AppService } from './app.service';
import { IAccount } from './app.interface';
export declare class AppSchema {
    route: string;
    description: string;
    method: string;
    constructor(route: string, desc: string, method: string);
}
export declare class AppController {
    private app;
    constructor(app: AppService);
    appRoot(): AppSchema[];
    example(): Array<IAccount>;
}
