/// <reference types="express" />
import { AppService } from './app.service';
import { IMember, IAccount } from './app.interface';
import { Request } from 'express';
import { Profile, ChangePassword, UpdateAccount, CreateAccount } from './app.classes';
export declare class MemberController {
    private service;
    constructor(service: AppService);
    getItemDta(req: Request): IAccount;
    updateProfile(req: Request, body: Profile): IAccount;
    changePassword(req: Request, body: ChangePassword): IAccount;
    getItems(req: Request): IMember;
    getItem(id: any): IAccount;
    deleteItem(id: any): IAccount[];
    createItem(body: CreateAccount): IAccount;
    updateItem(id: any, body: UpdateAccount): IAccount;
}
