import { AppService } from './app.service';
import { IAccount } from './app.interface';
import { AuthenService } from './authen.service';
import { Register, Login } from './app.classes';
export declare class AccountController {
    private service;
    private authen;
    constructor(service: AppService, authen: AuthenService);
    register(register: Register): IAccount;
    login(login: Login): {
        accessToken: string;
    };
}
