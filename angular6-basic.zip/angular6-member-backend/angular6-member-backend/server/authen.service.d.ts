import { AppService } from './app.service';
import { IAccount, JwtPayload } from './app.interface';
export declare class AuthenService {
    private service;
    constructor(service: AppService);
    createToken(userLogin: IAccount): {
        accessToken: string;
    };
}
declare const JwtStrategy_base: new (...args: any[]) => any;
export declare class JwtStrategy extends JwtStrategy_base {
    private service;
    constructor(service: AppService);
    validate(payload: JwtPayload, next: Function): Promise<any>;
}
