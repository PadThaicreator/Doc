"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const app_service_1 = require("./app.service");
const authen_service_1 = require("./authen.service");
const validation_pipe_1 = require("./validation.pipe");
const app_classes_1 = require("./app.classes");
let AccountController = class AccountController {
    constructor(service, authen) {
        this.service = service;
        this.authen = authen;
    }
    register(register) {
        if (register.password === register.cpassword)
            return this.service.postRegister(register);
        throw new common_1.BadRequestException('รหัสผ่านและยืนยันรหัสผ่านไม่ถูกต้อง');
    }
    login(login) {
        const userLogin = this.service.postLogin(login);
        if (!userLogin)
            throw new common_1.BadRequestException('ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง');
        return this.authen.createToken(userLogin);
    }
};
__decorate([
    common_1.Post('register'),
    __param(0, common_1.Body(new validation_pipe_1.ValidationPipe())),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [app_classes_1.Register]),
    __metadata("design:returntype", Object)
], AccountController.prototype, "register", null);
__decorate([
    common_1.Post('login'),
    __param(0, common_1.Body(new validation_pipe_1.ValidationPipe())),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [app_classes_1.Login]),
    __metadata("design:returntype", void 0)
], AccountController.prototype, "login", null);
AccountController = __decorate([
    common_1.Controller('api/account'),
    __metadata("design:paramtypes", [app_service_1.AppService,
        authen_service_1.AuthenService])
], AccountController);
exports.AccountController = AccountController;
//# sourceMappingURL=account.controller.js.map