import { IRegister, ILogin, IProfile, IChangePassword, IAccount, IRoleAccount } from './app.interface';
export declare class Register implements IRegister {
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    cpassword: string;
}
export declare class Login implements ILogin {
    email: string;
    password: string;
    remember: boolean;
}
export declare class Profile implements IProfile {
    firstname: string;
    lastname: string;
    position: string;
    image: string;
}
export declare class ChangePassword implements IChangePassword {
    old_pass: string;
    new_pass: string;
}
export declare class CreateAccount implements IAccount {
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    id?: any;
    position?: string;
    image?: string;
    role?: IRoleAccount;
    created?: Date;
    updated?: Date;
}
export declare class UpdateAccount implements IAccount {
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    id?: any;
    position?: string;
    image?: string;
    role?: IRoleAccount;
    created?: Date;
    updated?: Date;
}
