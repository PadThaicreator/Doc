"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const app_service_1 = require("./app.service");
const app_classes_1 = require("./app.classes");
let MemberController = class MemberController {
    constructor(service) {
        this.service = service;
    }
    getItemDta(req) {
        const userLogin = req.user;
        return userLogin;
    }
    updateProfile(req, body) {
        return this.service.postUpdateProfile(req.user.id, body);
    }
    changePassword(req, body) {
        return this.service.postChangePassword(req.user.id, body);
    }
    getItems(req) {
        return this.service.getItems({
            startPage: req.query['startPage'] || 1,
            limitPage: req.query['limitPage'] || 10,
            searchType: req.query['searchType'] || 'email',
            searchText: req.query['searchText'] || ''
        });
    }
    getItem(id) {
        return this.service.getItemById(id);
    }
    deleteItem(id) {
        return this.service.deleteItem(id);
    }
    createItem(body) {
        return this.service.createItem(body);
    }
    updateItem(id, body) {
        return this.service.updateItem(id, body);
    }
};
__decorate([
    common_1.Get('data'),
    __param(0, common_1.Req()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "getItemDta", null);
__decorate([
    common_1.Post('profile'),
    __param(0, common_1.Req()), __param(1, common_1.Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, app_classes_1.Profile]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "updateProfile", null);
__decorate([
    common_1.Post('change-password'),
    __param(0, common_1.Req()), __param(1, common_1.Body()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, app_classes_1.ChangePassword]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "changePassword", null);
__decorate([
    common_1.Get(),
    __param(0, common_1.Req()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Object)
], MemberController.prototype, "getItems", null);
__decorate([
    common_1.Get(':id'),
    __param(0, common_1.Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "getItem", null);
__decorate([
    common_1.Delete(':id'),
    __param(0, common_1.Param('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "deleteItem", null);
__decorate([
    common_1.Post(),
    __param(0, common_1.Body(new common_1.ValidationPipe())),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [app_classes_1.CreateAccount]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "createItem", null);
__decorate([
    common_1.Put(':id'),
    __param(0, common_1.Param('id')), __param(1, common_1.Body(new common_1.ValidationPipe())),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, app_classes_1.UpdateAccount]),
    __metadata("design:returntype", void 0)
], MemberController.prototype, "updateItem", null);
MemberController = __decorate([
    common_1.Controller('api/member'),
    common_1.UseGuards(passport_1.AuthGuard('jwt')),
    __metadata("design:paramtypes", [app_service_1.AppService])
], MemberController);
exports.MemberController = MemberController;
//# sourceMappingURL=member.controller.js.map