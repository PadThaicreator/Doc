import { FormGroup } from "@angular/forms";
import { IRoleAccount } from "src/app/shareds/services/account.service";

export interface IMemberCreateComponent {
    memId : any;
    positionItems: string[];
    roleItems : IRoleAccount[];
    getRoleName(role : IRoleAccount) : string ;

    form : FormGroup;
    onSave() : void;
    onConvertImage(input : HTMLInputElement);
}