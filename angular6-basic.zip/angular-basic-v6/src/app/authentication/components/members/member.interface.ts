import { PageChangedEvent } from "ngx-bootstrap";
import { IAccount, IRoleAccount } from "src/app/shareds/services/account.service";

export interface IMembersComponent {
    items : IMember;

    getRoleUser (role : IRoleAccount) : string;

    onSearchItem () : void;
    onPageChange(page : PageChangedEvent)
    onDelete(item : IAccount) : void;
    editMember(item : IAccount) : void;
    // searching

    searchText : string;
    searchType : IMemberSearchKey
    searchTypeItems : IMemberSearchKey[]
    Role : typeof IRoleAccount
    UserLogin : IAccount
    startPage : number ;
    limitPage : number;
}

export interface IMemberSeacrh {
    searchText? : string;
    searchType? : string;
    startPage : number;
    limitPage : number;
}
export interface IMemberSearchKey {
    key : string ;
    value : string;
}

export interface IMember {
    items : IAccount[];
    totalItems : number;
}