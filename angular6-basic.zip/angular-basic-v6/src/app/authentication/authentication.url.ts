export const AuthURL = {
    Dashboard : 'dashboard',
    Setting : 'setting',
    Profile : 'profile',
    Element : 'bootstrap-elements',
    Card : 'card',
    Widget : 'widget',
    AllMembers : 'all-members',
    CreateMember : 'create-member'
}