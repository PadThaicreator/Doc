import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AccountService, IRoleAccount } from '../shareds/services/account.service';
import { AuthenService } from '../services/authen.service';

@Injectable({
  providedIn: 'root'
})
export class UserRoleGuard implements CanActivate {

  constructor(
    private router: Router,
    private authen: AuthenService,
    private account: AccountService
  ) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return new Promise<boolean>((resolve, reject) => {
      const roles: IRoleAccount[] = next.data.role;

      this.account.getUserLogin(this.authen.getAuthentication())
        .then(res => {
          if (roles.filter(item => item == res.role).length > 0)
            resolve(true);
          else
            resolve(false)
        })
        .catch(err => {
          resolve(false)
        })


    })
  }
}
