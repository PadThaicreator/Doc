import { Component, OnInit } from '@angular/core';
import { AppURL } from 'src/app/app.url';
import { AuthURL } from 'src/app/authentication/authentication.url';
import { IAuthSidebarComponent } from './auth-sidebar.interface';
import { AccountService, IAccount, IRoleAccount } from '../../services/account.service';
import { AuthenService } from 'src/app/services/authen.service';
import { AlertService } from '../../services/alert.service';
import { Router } from '@angular/router';
declare const App;
@Component({
  selector: 'app-auth-sidebar',
  templateUrl: './auth-sidebar.component.html',
  styleUrls: ['./auth-sidebar.component.css']
})
export class AuthSidebarComponent implements OnInit , IAuthSidebarComponent {

  constructor(
     private account : AccountService,
    private authen : AuthenService,
    private alert : AlertService,
    private router : Router
  ) { 
      this.initialLoadUserLogin()
  }
   
  ngOnInit() {
    
  }

  AppUrl = AppURL;
  AuthUrl = AuthURL;
  UserLogin: IAccount;
  Role = IRoleAccount;

  private initialLoadUserLogin(){
    this.UserLogin = this.account.UserLogin
    if(this.UserLogin.id) return  setTimeout(() => App.initialLoadPage() , 100);
    this.account.getUserLogin(this.authen.getAuthentication())
    .then(res => {
      console.log("User Here")
        console.log(res)
        this.UserLogin = res;

        setTimeout(() => App.initialLoadPage() , 100)
    })
    .catch(err => {
      this.alert.notify(err.Message , "warning")
      this.authen.clearAuthentication();
      this.router.navigate(["/" , AppURL.Login])
    })
  }

}
